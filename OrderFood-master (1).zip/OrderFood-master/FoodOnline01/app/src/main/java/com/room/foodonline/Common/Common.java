package com.room.foodonline.Common;

import com.room.foodonline.Model.User;

public class Common {
    public static User currentuser;
}
