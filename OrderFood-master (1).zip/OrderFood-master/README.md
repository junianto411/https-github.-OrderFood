# OrderFood
Android APP
Aplikasi ini adalah salahsatu Tugas Final Project Pemrograman mobile
jika mau silahkan clone
//
//

//Anggota Kelompok
//Enrico Nugroho 16.11.0804
//Dwi Ponco Utomo 16.11.0854
//Muhammad Rizal H. 16.11.0845
//Adi Surya B. 16.11.0808
